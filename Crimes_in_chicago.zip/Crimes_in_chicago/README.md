# ADS_Project

# Crimes In Chicago 

## Contributors :
- Birwa Galia
- Milony Mehta
- Shantanu Deosthale


## The link to the application can be found here [Crimes in Chicago] ( http://ec2-18-204-35-0.compute-1.amazonaws.com/ )

## The Flask Application [Flask App] (./Final Project ADS)

## Exploratory Data Analysis for crimes in chicago [Exploratory Data Analysis] (./Crimes In Chicago(EDA).ipynb)

## [Team Report] (./Final_project_report.pdf)

## [Airflow_Pipeline] (./Final_project_pipe.py)


